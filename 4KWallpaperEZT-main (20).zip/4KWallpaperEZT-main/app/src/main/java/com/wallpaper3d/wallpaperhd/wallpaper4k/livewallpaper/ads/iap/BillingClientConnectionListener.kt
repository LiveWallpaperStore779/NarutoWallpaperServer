package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ads.iap

interface BillingClientConnectionListener {
    fun onConnected(status: Boolean, billingResponseCode: Int)
}