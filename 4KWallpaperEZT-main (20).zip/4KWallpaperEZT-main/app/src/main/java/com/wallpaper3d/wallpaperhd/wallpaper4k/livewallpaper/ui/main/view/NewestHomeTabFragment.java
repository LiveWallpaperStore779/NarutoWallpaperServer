package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.main.view;

import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.R;
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.base.BaseFragment;
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.databinding.FragmentCategoryBinding;

public class NewestHomeTabFragment extends BaseFragment<FragmentCategoryBinding> {
    @Override
    public int getLayoutRes() {
        return R.layout.fragment_category;
    }

    @Override
    public void initView() {

    }

    @Override
    public void initData() {

    }

    @Override
    public void setListener() {

    }

    @Override
    public void setObserver() {

    }

    @Override
    public int getFrame() {
        return R.id.mainFrame;
    }
}
