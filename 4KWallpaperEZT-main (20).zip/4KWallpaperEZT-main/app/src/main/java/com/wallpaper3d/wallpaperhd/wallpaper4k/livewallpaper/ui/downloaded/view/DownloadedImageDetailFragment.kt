package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.downloaded.view

import android.Manifest
import android.annotation.SuppressLint
import android.app.ProgressDialog
import android.app.WallpaperManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.AsyncTask
import android.os.Build
import android.os.StrictMode
import android.os.StrictMode.VmPolicy
import android.provider.MediaStore
import android.util.Log
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.R
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.WeatherApplication
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.base.BaseFragment
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.databinding.FragmentDetailDownloadedImageBinding
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.iinterface.OnClick
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.downloaded.adapter.SlideDownloadedImageAdapter
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.newlivewallpaper.task.Image
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.slideimage.view.InstallDialog
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL


class DownloadedImageDetailFragment : BaseFragment<FragmentDetailDownloadedImageBinding?>(),
    OnClick {
    private var imageAdapter: SlideDownloadedImageAdapter? = null
    private var listImage: ArrayList<Image>? = null

    private var currentPosition: Int = 0

    private var wallpaperManager: WallpaperManager? = null

    private var progressDialog : ProgressDialog? = null

    public fun setData(listImage: ArrayList<Image>?, currentPosition: Int) {
        this.listImage = listImage
        this.currentPosition = currentPosition
    }

    override fun getLayoutRes(): Int {
        return R.layout.fragment_detail_downloaded_image
    }

    override fun initView() {
        imageAdapter = SlideDownloadedImageAdapter(mActivity, listImage, null)
        binding?.vpContent?.adapter = imageAdapter
        binding?.vpContent?.currentItem = currentPosition

        progressDialog = ProgressDialog(mActivity, ProgressDialog.THEME_HOLO_DARK)


    }

    private fun showProgress(message: String){
        progressDialog?.setMessage(message)
        progressDialog?.show()
    }

    override fun initData() {
        wallpaperManager = WallpaperManager.getInstance(mActivity)
    }



    override fun setListener() {
        binding?.btnBack?.setOnClickListener {
            mActivity.onBackPressed()
        }

        binding?.btnSetImage?.setOnClickListener {
            var optionDialog = InstallDialog();
            optionDialog.setOnClick(this)
            optionDialog.show(childFragmentManager, "");
            WeatherApplication.trackingEvent("Click_Set_Image_Downloaded_Image_Detail")
        }

        binding?.btnShare?.setOnClickListener {
            if (ContextCompat.checkSelfPermission(mActivity, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(mActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 123)
                requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 123)
            } else {
                showProgress(mActivity.getString(R.string.preparing_photo_to_share))
                ShareImage().execute()
            }

            WeatherApplication.trackingEvent("Click_Share_Downloaded_Image_Detail")
        }

    }


    inner class ShareImage() : AsyncTask<String?, Int?, String?>() {
        override fun doInBackground(vararg string: String?): String? {
            shareImageUri(listImage!![binding?.vpContent?.currentItem!!].uri)
            return null
        }

        override fun onPreExecute() {
            super.onPreExecute()

        }

        override fun onPostExecute(result: String?) {
            super.onPostExecute(result)
            try {
                progressDialog!!.dismiss()
            } catch (e: Exception) {
                e.printStackTrace()
            }

        }
    }

    public fun shareImageUri(uri: Uri) {
        try {
            val builder = VmPolicy.Builder()
            StrictMode.setVmPolicy(builder.build())
            val intent = Intent(Intent.ACTION_SEND)
            intent.putExtra(Intent.EXTRA_STREAM, uri)
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            intent.type = "image/png"
            startActivity(intent)
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }
    }

    fun getImageUri(linkImage: String?): Uri? {
        return try {
            val url = URL(linkImage)
            val connection = url.openConnection() as HttpURLConnection
            connection.doInput = true
            connection.connect()
            val input = connection.inputStream
            val myBitmap = BitmapFactory.decodeStream(input)
            val bytes = ByteArrayOutputStream()
            myBitmap.compress(Bitmap.CompressFormat.JPEG, 100, bytes)
            var ts = System.currentTimeMillis().toString()
            val path = MediaStore.Images.Media.insertImage(mActivity.contentResolver, myBitmap, ts+"Title", ts)
            Uri.parse(path)
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
            null
        }
    }

    override fun setObserver() {
    }

    @SuppressLint("StaticFieldLeak")
    override fun onClickToLockScreen() {
        showProgress(mActivity.getString(R.string.setting_wallpaper))
        object : AsyncTask<Void?, Void?, Void?>() {


            override fun onPostExecute(aVoid: Void?) {
                super.onPostExecute(aVoid)
                progressDialog?.dismiss()
                Toast.makeText(mActivity, mActivity.getString(R.string.set_image_as_lock_screen_successfully), Toast.LENGTH_LONG).show()
            }

            override fun doInBackground(vararg p0: Void?): Void? {
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        wallpaperManager!!.setBitmap(getBitmapFromURI(listImage!![binding?.vpContent?.currentItem!!].uri), null, true, WallpaperManager.FLAG_LOCK)
                    } else {
                        wallpaperManager!!.setBitmap(getBitmapFromURI(listImage!![binding?.vpContent?.currentItem!!].uri))
                    }

                } catch (e: java.lang.Exception) {
                }
                return null
            }

        }.execute()
    }

    @SuppressLint("StaticFieldLeak")
    override fun onClickToBoth() {
        showProgress(mActivity.getString(R.string.setting_wallpaper))
        object : AsyncTask<Void?, Void?, Void?>() {


            override fun onPostExecute(aVoid: Void?) {
                super.onPostExecute(aVoid)
                progressDialog?.dismiss()
                Toast.makeText(mActivity, mActivity.getString(R.string.set_as_both_success), Toast.LENGTH_LONG).show()
            }

            override fun doInBackground(vararg p0: Void?): Void? {
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        wallpaperManager!!.setBitmap(getBitmapFromURI(listImage!![binding?.vpContent?.currentItem!!].uri), null, true, WallpaperManager.FLAG_SYSTEM)
                    } else {
                        wallpaperManager!!.setBitmap(getBitmapFromURI(listImage!![binding?.vpContent?.currentItem!!].uri))
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        wallpaperManager!!.setBitmap(getBitmapFromURI(listImage!![binding?.vpContent?.currentItem!!].uri), null, true, WallpaperManager.FLAG_LOCK)
                    } else {
                        wallpaperManager!!.setBitmap(getBitmapFromURI(listImage!![binding?.vpContent?.currentItem!!].uri))
                    }
                } catch (e: java.lang.Exception) {
                    Log.e("", "")
                }
                return null
            }

        }.execute()
    }

    @SuppressLint("StaticFieldLeak")
    override fun onClickToMainScreen() {
        showProgress(mActivity.getString(R.string.setting_wallpaper))
        object : AsyncTask<Void?, Void?, Void?>() {


            override fun onPostExecute(aVoid: Void?) {
                super.onPostExecute(aVoid)
                progressDialog?.dismiss()
                Toast.makeText(mActivity, mActivity.getString(R.string.set_image_as_main_screen_success), Toast.LENGTH_LONG).show()
            }

            override fun doInBackground(vararg p0: Void?): Void? {
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        wallpaperManager!!.setBitmap(getBitmapFromURI(listImage!![binding?.vpContent?.currentItem!!].uri), null, true, WallpaperManager.FLAG_SYSTEM)
                    } else {
                        wallpaperManager!!.setBitmap(getBitmapFromURI(listImage!![binding?.vpContent?.currentItem!!].uri))
                    }

                } catch (e: Exception) {
                    Log.e("", "");
                }
                return null
            }

        }.execute()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 123) {
            if (grantResults.isNotEmpty()) {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    showProgress(mActivity.getString(R.string.preparing_photo_to_share))
                    ShareImage().execute()
                } else {
                }
            } else {
            }
        }
    }

    private fun getBitmapFromURI(uri : Uri) : Bitmap{
        return MediaStore.Images.Media.getBitmap(mActivity.contentResolver, uri)
    }

    override fun getFrame(): Int {
        return R.id.mainFrame
    }
}