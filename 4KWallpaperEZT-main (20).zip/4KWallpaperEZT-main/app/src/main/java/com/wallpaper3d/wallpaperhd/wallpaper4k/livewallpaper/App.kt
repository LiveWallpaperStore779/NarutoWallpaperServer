package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper

import android.app.Application


class App : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}