package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.main.model.category;

import java.util.ArrayList;

public class CategoryResponse {
    private ArrayList<Category> items;

    public ArrayList<Category> getItems() {
        return items;
    }

    public void setItems(ArrayList<Category> items) {
        this.items = items;
    }

}
