package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.iinterface;

public interface ClickViewAds {
    void onClickViewAds();
}
