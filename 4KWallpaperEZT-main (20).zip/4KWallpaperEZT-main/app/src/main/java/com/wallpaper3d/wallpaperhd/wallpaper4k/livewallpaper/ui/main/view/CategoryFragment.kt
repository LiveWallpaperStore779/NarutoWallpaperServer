package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.main.view

import android.view.View
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.base.BaseFragment
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.R
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.WeatherApplication
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.databinding.FragmentCategoryBinding
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.main.adapter.CategoryInPageAdapter
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.main.model.category.Category
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.main.viewmodel.WeatherViewModel
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.util.toGone
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.util.toVisible
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class CategoryFragment : BaseFragment<FragmentCategoryBinding?>() {
    private var categoryInPageAdapter: CategoryInPageAdapter? = null
    private var listCategory = ArrayList<Category>()
    private val weatherViewModel: WeatherViewModel by viewModels()
    override fun getLayoutRes(): Int {
        return R.layout.fragment_category
    }

    override fun initView() {}
    override fun initData() {
        weatherViewModel.getAllCat()
        binding?.swipeToRefresh?.setOnRefreshListener {
            weatherViewModel.getAllCat()
            binding?.progressBar?.visibility = View.VISIBLE
            WeatherApplication.trackingEvent("Refresh_Category")
        }

    }
    override fun setListener() {
        binding?.btnReload?.setOnClickListener {
            binding?.layoutReload?.toGone()
            binding?.progressBar?.visibility = View.VISIBLE
            weatherViewModel.getAllCat()
            WeatherApplication.trackingEvent("Refresh_Category")
        }
    }
    override fun setObserver() {
        weatherViewModel.categoryResponseLiveData.observe(this, Observer {
            binding?.swipeToRefresh?.isRefreshing = false
            binding?.progressBar?.visibility = View.GONE
            categoryInPageAdapter = CategoryInPageAdapter(mActivity, it.items, weatherViewModel, this)
            binding?.rclCategory?.adapter = categoryInPageAdapter
            binding?.rclCategory?.toVisible()

            binding?.rclCategory?.setHasFixedSize(true)
            binding?.rclCategory?.setItemViewCacheSize(40)
        })

        weatherViewModel.requestFail.observe(this) {
            binding?.progressBar?.toGone()
            binding?.swipeToRefresh?.isRefreshing = false
            binding?.layoutReload?.toVisible()
            binding?.rclCategory?.toGone()
        }
    }
    override fun getFrame(): Int {
        return R.id.mainFrame
    }
}