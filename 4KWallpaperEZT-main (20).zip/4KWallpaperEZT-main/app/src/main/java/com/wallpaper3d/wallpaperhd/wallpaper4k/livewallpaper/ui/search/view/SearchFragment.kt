package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.search.view

import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.R
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.WeatherApplication
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.base.BaseFragment
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.databinding.FragmentSearchBinding
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.main.viewmodel.WeatherViewModel
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.search.adapter.TagTrendingAdapter
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.search.model.PopularTag
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.util.PreferenceUtil
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.util.toGone
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class SearchFragment : BaseFragment<FragmentSearchBinding?>() {
    private val weatherViewModel : WeatherViewModel by viewModels()
    private var tagTrendingAdapter : TagTrendingAdapter? = null
    private val listPopularTag : ArrayList<PopularTag> = ArrayList()

    @Inject lateinit var preferenceUtil: PreferenceUtil
    override fun getLayoutRes(): Int {
        return R.layout.fragment_search
    }

    override fun initView() {}
    override fun initData() {
        weatherViewModel.getPopularTag()
        tagTrendingAdapter = TagTrendingAdapter(mActivity, listPopularTag, this)
        binding?.rcvTagTrending?.adapter = tagTrendingAdapter

    }
    override fun setListener() {
        binding?.btnBack?.setOnClickListener { mActivity.onBackPressed() }
        binding?.edtSearch?.setOnClickListener {
            WeatherApplication.trackingEvent("Click_EdtSearch")
            var searchResultFragment = SearchResultFragment();
            searchResultFragment.setShowKeyboard(true)
            addFragment(searchResultFragment)
        }
    }


    override fun setObserver() {
        weatherViewModel.popularTagResponse.observe(this, Observer {
            binding?.progressBar?.toGone()
            listPopularTag.addAll(it.items)
            tagTrendingAdapter?.notifyDataSetChanged()
        })
    }
    override fun getFrame(): Int {
        return R.id.mainFrame
    }
}