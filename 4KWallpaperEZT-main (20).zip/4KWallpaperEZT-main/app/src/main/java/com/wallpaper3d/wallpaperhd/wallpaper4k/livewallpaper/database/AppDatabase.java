package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.model.CheckVersion;
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.model.Favorite;
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.model.Recent;
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.main.model.image.DataConverter;
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.main.model.image.Image;
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.main.model.image.TagDataConverter;

@Database(entities  = {CheckVersion.class, Favorite.class, Recent.class, Image.class} , version = 16)
@TypeConverters({ DataConverter.class, TagDataConverter.class})
public abstract class AppDatabase extends RoomDatabase {
    private static AppDatabase INSTANCE;

    public abstract WeatherDao foodDao();

    public static AppDatabase getInMemoryDatabase(Context context) {

        INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                AppDatabase.class, "wallpaper4k").allowMainThreadQueries().fallbackToDestructiveMigration().build();
        return INSTANCE;
    }

    public static void destroyInstance() {
        INSTANCE = null;
    }
}
