package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.main;

import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.main.model.Promotion;

import java.util.ArrayList;

public class PromotionData {

    private ArrayList<Promotion> promotion;

    public ArrayList<Promotion> getMenu() {
        return promotion;
    }

    public void setMenu(ArrayList<Promotion> menu) {
        this.promotion = promotion;
    }
}
