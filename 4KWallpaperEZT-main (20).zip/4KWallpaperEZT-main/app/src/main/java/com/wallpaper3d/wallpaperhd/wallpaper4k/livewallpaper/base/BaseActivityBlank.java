package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.base;

import androidx.appcompat.app.AppCompatActivity;

public class BaseActivityBlank extends AppCompatActivity {
}
