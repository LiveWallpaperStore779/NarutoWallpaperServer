package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.similar.adapter

import android.app.Activity
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.R
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ads.InterAds
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.iinterface.DataChange
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.main.model.image.Image
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.similar.DetailSimilarImageActivity
import kotlinx.android.synthetic.main.item_image.view.*
import kotlin.collections.ArrayList

class SimilarImageAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private val TYPE_ITEM = 0
    private var context: Context? = null
    private var images: List<Image>? = null
    private var dataChange : DataChange? = null


    constructor()
    constructor(context: Context?, datas: List<Image>?) : super() {
        this.context = context
        this.images = datas
    }


    override fun getItemViewType(position: Int): Int {
        return TYPE_ITEM
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        var v: View = LayoutInflater.from(parent.context).inflate(R.layout.item_image, parent, false)
        return ViewHolder(v)
    }

    override fun getItemCount(): Int {
        try {
            if(images!!.isNotEmpty()){
                dataChange?.onDataChange(false)
                return images!!.size;
            }else{
                dataChange?.onDataChange(true)
                return 0
            }
        } catch (e: Exception) {
            dataChange?.onDataChange(true)
            return 0
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        try {
            if (getItemViewType(position) == TYPE_ITEM) {
                (holder as ViewHolder).bindItem(position)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    inner class ViewHolder : RecyclerView.ViewHolder {
        private var position: Int? = 0;

        constructor(itemView: View?) : super(itemView!!) {
            itemView.setOnClickListener {
            }
        }

        fun bindItem(position: Int) {
            this.position = position

            val link = images!![position].variations.preview_small.url
            Glide.with(context!!).load(link).into(itemView.imgAvatar)
            itemView.setOnClickListener {
                InterAds.showAdsBreak(context as Activity){
                    DetailSimilarImageActivity.startScreen(
                        context!!,
                        images as ArrayList<Image>,
                        position,
                        images!![position].id
                    )
                }

            }
        }

    }

}

