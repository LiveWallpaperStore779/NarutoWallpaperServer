package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.downloaded.view

import android.Manifest
import android.content.pm.PackageManager
import android.os.Environment
import android.view.View
import androidx.core.content.ContextCompat

import com.allfree.wallpaperparallax.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.downloaded.adapter.ListImageDownloadedAdapter
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.R
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.WeatherApplication
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.base.BaseFragment
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.databinding.FragmentDownloadedBinding
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.iinterface.DataChange
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.newlivewallpaper.task.Image
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.newlivewallpaper.task.LoadAllImageFromFolder

class DownloadedFragment : BaseFragment<FragmentDownloadedBinding?>() {
    private var imageAdapter : ListImageDownloadedAdapter? = null;
    private var listImage = ArrayList<Image>()
    override fun getLayoutRes(): Int {
        return R.layout.fragment_downloaded
    }

    override fun initView() {}
    override fun initData() {
        imageAdapter = ListImageDownloadedAdapter(mActivity, listImage, DataChange {
            if(it){
                binding?.layoutTip?.visibility = View.VISIBLE
            }else{
                binding?.layoutTip?.visibility = View.GONE
            }
        }, object : ListImageDownloadedAdapter.ClickItem{
            override fun onClickItem(position:Int) {
                var downloadedImageDetailFragment = DownloadedImageDetailFragment()
                downloadedImageDetailFragment.setData(listImage, position)
                addFragment(downloadedImageDetailFragment)
            }

        })
        binding?.rclContent?.run {
            adapter = imageAdapter
            setHasFixedSize(true)
            setItemViewCacheSize(20)
            isDrawingCacheEnabled = true
            drawingCacheQuality = View.DRAWING_CACHE_QUALITY_HIGH
        }

        if (ContextCompat.checkSelfPermission(
                mActivity,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(
                mActivity,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 789)
            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 789)
        } else {
            getImage()
        }
    }
    override fun setListener() {
        binding?.btnBack?.setOnClickListener {
            mActivity.onBackPressed()
        }
    }
    override fun setObserver() {}

    public fun getImage() {
        val sdCard = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        val savedPath = sdCard.absolutePath + "/EZT4KWallpaper/"
        val loadAllImageFromFolder = LoadAllImageFromFolder(mActivity.contentResolver)
        loadAllImageFromFolder.setFolderPath(savedPath)
        loadAllImageFromFolder.onLoadDoneListener = object :
            LoadAllImageFromFolder.OnLoadDoneListener {
            override fun onLoadDone(images: List<Image>) {
                listImage.clear()
                listImage.addAll(images)

                mActivity.runOnUiThread {
                    imageAdapter!!.notifyDataSetChanged()
                }

            }

            override fun onLoadError() {}
        }
        loadAllImageFromFolder.execute()
    }


    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 789) {
            if (grantResults.isNotEmpty()) {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    getImage()
                } else {
                }
            } else {
            }
        }
    }

    override fun getFrame(): Int {
        return R.id.mainFrame
    }
}