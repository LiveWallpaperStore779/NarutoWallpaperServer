package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.main.model;

public class Location {
    public String geoplugin_countryName;
}
