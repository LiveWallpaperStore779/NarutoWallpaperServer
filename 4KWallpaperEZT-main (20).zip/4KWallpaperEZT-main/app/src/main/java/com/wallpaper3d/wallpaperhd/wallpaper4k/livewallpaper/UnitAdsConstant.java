package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper;

public class UnitAdsConstant {
    //testing
    public static class BannerId{
        public static final String MAIN_ID = "ca-app-pub-3940256099942544/6300978111";
        public static final String CATE_DETAIL_ID = "ca-app-pub-3940256099942544/6300978111";
    }

    public static class InterstitialId {
        public static final String MAIN_ID = "ca-app-pub-3940256099942544/1033173712";
    }

    public static class NativeId {
        public static final String MAIN_ID = "ca-app-pub-3940256099942544/2247696110";
    }

    public static class OpenId {
        public static final String MAIN_ID = "ca-app-pub-3940256099942544/3419835294";
    }


    //live
//    public static class BannerId{
//        public static final String MAIN_ID = "ca-app-pub-3940256099942544/6300978111";
//        public static final String CATE_DETAIL_ID = "ca-app-pub-3940256099942544/6300978111";
//    }
//
//    public static class InterstitialId {
//        public static final String MAIN_ID = "ca-app-pub-3940256099942544/1033173712";
//    }
//
//    public static class NativeId {
//        public static final String MAIN_ID = "ca-app-pub-3940256099942544/2247696110";
//    }
//
//    public static class OpenId {
//        public static final String MAIN_ID = "ca-app-pub-3940256099942544/3419835294";
//    }




}
