package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.search.model;

import java.util.ArrayList;

public class PopularTagResponse {
    private ArrayList<PopularTag> items;

    public ArrayList<PopularTag> getItems() {
        return items;
    }

    public void setItems(ArrayList<PopularTag> items) {
        this.items = items;
    }
}
