package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.search.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.WeatherApplication
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.databinding.ItemSearchHistoryBinding


class RecentAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private var context: Context? = null
    public var clickItem: ClickItem? = null
    private var comments: List<String>? = null

    constructor(comments: List<String>, context: Context, clickItem: ClickItem) {
        this.context = context
        this.clickItem = clickItem
        this.comments = comments
    }

    fun setData(comments: List<String>) {
        this.comments = comments
        notifyDataSetChanged()
    }

    override fun getItemViewType(position: Int): Int {
        return TYPE_ITEM
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)

        var v: View? = null
        return if (viewType == TYPE_ITEM) {
            val binding: ItemSearchHistoryBinding =
                ItemSearchHistoryBinding.inflate(inflater, parent, false)
            HeaderViewHolder(binding)
        } else {
            val binding: ItemSearchHistoryBinding =
                ItemSearchHistoryBinding.inflate(inflater, parent, false)
            HeaderViewHolder(binding)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        try {
            if (getItemViewType(position) == TYPE_ITEM) {
                (holder as HeaderViewHolder).bindItem(position)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun getItemCount(): Int {
        return try {
            comments!!.size
        } catch (e: Exception) {
            0
        }
    }

    inner class HeaderViewHolder(var binding: ItemSearchHistoryBinding) : RecyclerView.ViewHolder(binding.root) {
        private var position: Int? = 0


        init {

        }


        fun bindItem(position: Int?) {
            this.position = position
            binding.tvTitle.text = position?.let { comments?.get(it) }
            binding.root.setOnClickListener {
                WeatherApplication.trackingEvent("Click_Item_Recent")
                clickItem?.onClickItem(position?.let { it1 -> comments?.get(it1) })
            }
        }
    }

    interface ClickItem {
        fun onClickItem(string: String?)
    }

    companion object {
        private const val TYPE_ITEM = 0
    }

}