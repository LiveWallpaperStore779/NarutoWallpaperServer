package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.mywallpaper.view

import androidx.lifecycle.Observer
import com.bumptech.glide.Glide
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.Constant
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.R
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.WeatherApplication
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.base.BaseFragment
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.databinding.FragmentMyWallpaperBinding
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.main.adapter.ImageAdapter
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.main.model.image.Image
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.mywallpaper.viewmodel.MyWallpaperViewModel
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.util.toGone
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.util.toVisible

class MyWallpaperFragment : BaseFragment<FragmentMyWallpaperBinding?>() {
    private var myWallpaperType = Constant.MyWallpaperType.FAVORITE
    private var imageAdapter: ImageAdapter? = null
    private var listImage: ArrayList<Image> = ArrayList()
    private var myWallpaperViewModel: MyWallpaperViewModel? = null

    public fun setMyWallPaperType(myWallpaperType: String) {
        this.myWallpaperType = myWallpaperType
    }

    override fun getLayoutRes(): Int {
        return R.layout.fragment_my_wallpaper
    }

    override fun initView() {
        imageAdapter = ImageAdapter(mActivity, listImage)
        binding?.rclContent?.adapter = imageAdapter
    }

    override fun initData() {
        myWallpaperViewModel = MyWallpaperViewModel()
        if(myWallpaperType == Constant.MyWallpaperType.FAVORITE) {
            binding?.tvType?.text = "Favorite wallpapers"
            Glide.with(mActivity).load(R.drawable.ic_baseline_favorite_24_2).into(binding?.imgAvatar!!)
            binding?.tvTitle?.text = mActivity.getString(R.string.you_have_not_favorited_any_photos_yet)
            myWallpaperViewModel?.getAllFavoriteImage()
        }else{
            binding?.tvType?.text = "Install wallpapers"
            Glide.with(mActivity).load(R.drawable.ic_baseline_access_time_24_2).into(binding?.imgAvatar!!)
            binding?.tvTitle?.text = mActivity.getString(R.string.you_have_not_used_any_photos_as_wallpaper_yet)
            myWallpaperViewModel?.getAllRecentImage()
        }
    }

    override fun setListener() {
        binding?.btnBack?.setOnClickListener {
            mActivity.onBackPressed()
        }
    }
    override fun setObserver() {
        myWallpaperViewModel?.repos?.observe(this, Observer {
            listImage.addAll(it)
            if(listImage.size > 0){
                binding?.layoutTip?.toGone()
            }else{
                binding?.layoutTip?.toVisible()
            }
            imageAdapter?.notifyDataSetChanged()
        })

        myWallpaperViewModel?.reposRecent?.observe(this, Observer {
            listImage.addAll(it)
            if(listImage.size > 0){
                binding?.layoutTip?.toGone()
            }else{
                binding?.layoutTip?.toVisible()
            }
            imageAdapter?.notifyDataSetChanged()
        })
    }

    override fun getFrame(): Int {
        return R.id.mainFrame
    }
}