package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.charging;

public interface Task<T> {
    void success(T result);
}
