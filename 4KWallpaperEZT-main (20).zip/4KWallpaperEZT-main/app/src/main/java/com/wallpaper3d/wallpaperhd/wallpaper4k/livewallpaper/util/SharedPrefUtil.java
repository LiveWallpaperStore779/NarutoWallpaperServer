package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.util;

import android.content.SharedPreferences;

import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.Constant;


public class SharedPrefUtil {

    public static void insertTimeSchedule(SharedPreferences sharedPreferences, int data) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(Constant.PrefKey.SCHEDULE, data);
        editor.apply();
    }

    public static int getTimeSchedule(SharedPreferences sharedPreferences) {
        return sharedPreferences.getInt(Constant.PrefKey.SCHEDULE, 0);
    }


}
