

package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.newlivewallpaper;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;

import androidx.annotation.NonNull;

import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.R;
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.newlivewallpaper.task.Image;


import org.json.JSONArray;
import org.json.JSONException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@SuppressWarnings("WeakerAccess")
public class LWApplication extends Application {
    @SuppressWarnings("unused")
    private static final String TAG = "LWApplication";
    public static final String JSON_FILE_NAME = "data.json";
    private static final String CURRENT_CARD_PREF = "currentWallpaperCard";
    public static final String OPTIONS_PREF = "options";
    public static final String SLIDE_WALLPAPER_KEY = "slideWallpaper";
    private static final String INTERNAL_WALLPAPER_IMAGE_PATH = "wallpapers/fire-rain/fire-rain-512x384.webp";
    private static final String INTERNAL_WALLPAPER_VIDEO_PATH = "wallpapers/fire-rain/fire-rain-720x720.mp4";
    private static List<WallpaperCard> cards = null;
    private static WallpaperCard currentWallpaperCard = null;
    private static WallpaperCard previewWallpaperCard = null;




    private static ArrayList<Image> listImageDownloaded = null;

    public static void setListImageDownloaded(ArrayList<Image> listImageDownloaded) {
        LWApplication.listImageDownloaded = listImageDownloaded;
    }



    public static WallpaperCard testCard = null;

    @NonNull
    public static List<WallpaperCard> getCards(@NonNull final Context context) {
        if (cards == null) {
            initCards(context);
        }
        return cards;
    }

    public static WallpaperCard getCurrentWallpaperCard(@NonNull final Context context) {
        if (currentWallpaperCard == null) {
            currentWallpaperCard = loadWallpaperCardPreference(context);
        }
        return currentWallpaperCard;
    }

    public static void setCurrentWallpaperCard(@NonNull final Context context, final WallpaperCard wallpaperCard) {
        currentWallpaperCard = wallpaperCard;
        if (wallpaperCard != null) {
            saveWallpaperCardPreference(context, wallpaperCard);
        }
    }

    public static boolean isCurrentWallpaperCard(WallpaperCard wallpaperCard) {
        // Only check variable, no SharedPreference.
        // If wallpaper is not this app, Preference should not be cleared,
        // only currentWallpaperCard is set to null.
        // Because when we getCurrentWallpaperCard(), it loads Preference,
        // and set currentWallpaperCard to non-null.
        // We want to detect whether service is selected
        // by checking whether currentWallpaperCard is null.
        // If we use getCurrentWallpaperCard(), we cannot archive this.
        return currentWallpaperCard != null && wallpaperCard.equals(currentWallpaperCard);
    }

    public static WallpaperCard getPreviewWallpaperCard() {
        return previewWallpaperCard;
    }

    public static void setPreviewWallpaperCard(final WallpaperCard wallpaperCard) {
        previewWallpaperCard = wallpaperCard;
    }

    public static JSONArray getCardsJSONArray() throws JSONException {
        JSONArray jsonArray = new JSONArray();
        if (cards != null) {
            for (WallpaperCard card : cards) {
                // INTERNAL WallpaperCard don't need to save.
                if (card.getType() != WallpaperCard.Type.INTERNAL) {
                    jsonArray.put(card.toJSON());
                }
            }
        }
        return jsonArray;
    }

    private static void saveWallpaperCardPreference(@NonNull final Context context, final WallpaperCard wallpaperCard) {
        final SharedPreferences pref = context.getSharedPreferences(CURRENT_CARD_PREF, MODE_PRIVATE);
        // Save to preference.
        final SharedPreferences.Editor prefEditor = pref.edit();
        prefEditor.putString("name", wallpaperCard.getName());
        prefEditor.putString("path", wallpaperCard.getPath());
        switch (wallpaperCard.getType()) {
        case INTERNAL:
            prefEditor.putString("type",  "INTERNAL");
            break;
        case EXTERNAL:
            prefEditor.putString("type", "EXTERNAL");
            break;
        }
        prefEditor.apply();
    }

    private static WallpaperCard loadWallpaperCardPreference(@NonNull final Context context) {
        final SharedPreferences pref = context.getSharedPreferences(CURRENT_CARD_PREF, MODE_PRIVATE);
        final String name = pref.getString("name", null);
        final String path = pref.getString("path", null);
        if (name == null || path == null) {
            return null;
        }
        WallpaperCard.Type type = WallpaperCard.Type.EXTERNAL;
        Uri uri;
        if (Objects.equals(pref.getString("type", null), "INTERNAL")) {
            type = WallpaperCard.Type.INTERNAL;
            uri = Uri.parse("file:///android_asset/" + path);
        } else {
            uri = Uri.parse(path);
        }
        return new WallpaperCard(name, path, uri, type, null);
    }

    private static void initCards(@NonNull final Context context) {
        cards = new ArrayList<>();
        Bitmap thumbnail = null;
        try {
            thumbnail = BitmapFactory.decodeStream(
                context.getAssets().open(INTERNAL_WALLPAPER_IMAGE_PATH)
            );
        } catch (IOException e) {
            e.printStackTrace();
        }
        cards.add(new WallpaperCard(
            context.getResources().getString(R.string.fire_rain),
            INTERNAL_WALLPAPER_VIDEO_PATH, Uri.parse(
                "file:///android_asset/" + INTERNAL_WALLPAPER_VIDEO_PATH
            ), WallpaperCard.Type.INTERNAL, thumbnail
        ));
    }

    public static ArrayList<Image> getListImageDownloaded() {
        return listImageDownloaded;
    }
}
