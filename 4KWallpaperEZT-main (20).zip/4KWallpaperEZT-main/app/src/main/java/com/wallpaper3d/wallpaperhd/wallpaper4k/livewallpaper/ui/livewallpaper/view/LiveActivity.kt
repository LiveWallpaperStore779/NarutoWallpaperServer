package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.livewallpaper.view

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.view.View
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.R
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.WeatherApplication
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ads.InterAds
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.base.BaseActivityNew
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.base.BaseFragment
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.databinding.ActivityLiveWallpaperBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class LiveActivity : BaseActivityNew<ActivityLiveWallpaperBinding?>() {
    override fun getLayoutRes(): Int {
        return R.layout.activity_live_wallpaper
    }

    override fun getFrame(): Int {
        return R.id.mainFrame
    }

    override fun getDataFromIntent() {}
    override fun doAfterOnCreate() {}
    override fun initFragment(): BaseFragment<*>? {
        var liveWallpaperFragment = LiveWallpaperFragment()
        liveWallpaperFragment.setShowToolbar(true)
        return liveWallpaperFragment
    }

    public companion object {
        public fun startScreen(context: Context) {
            var intent = Intent(context, LiveActivity::class.java)
            context.startActivity(Intent(intent))
        }
    }
    override fun afterSetContentView() {
        super.afterSetContentView()
        setFullScreen()
    }

    private fun setFullScreen() {
        super.afterSetContentView()
        window.decorView.systemUiVisibility =
            (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
        window.statusBarColor = Color.TRANSPARENT
    }


    override fun onBackPressed() {
        InterAds.showAdsBreak(this) {
            super.onBackPressed()
        }
    }

    override fun setListener() {

    }
}