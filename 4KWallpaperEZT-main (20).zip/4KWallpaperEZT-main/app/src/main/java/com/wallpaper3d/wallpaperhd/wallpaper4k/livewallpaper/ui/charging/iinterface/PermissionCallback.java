package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.charging.iinterface;

import android.app.Dialog;

public interface PermissionCallback {
    void OnSkip();
    void OnBack(Dialog dialog);
}
