package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.charging.iinterface;

public interface BatteryCallback {
    void OnBatteryConnected();
    void OnBatteryDisconnected();
    void OnBatteryChanged();
}
