package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.charging.model;

public class OnUpdateList {
}
