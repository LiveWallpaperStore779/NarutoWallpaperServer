package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.categorydetail.view

import android.view.View
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.RecyclerView
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.Constant
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.R
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.WeatherApplication
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.base.BaseFragment
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.databinding.FragmentCategoryTabDetailBinding
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.main.adapter.ImageAdapter
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.main.model.image.Image
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.main.viewmodel.WeatherViewModel
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.util.toGone
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.util.toVisible
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class CategoryDetailTabFragment : BaseFragment<FragmentCategoryTabDetailBinding?>() {

    private val mainViewModel : WeatherViewModel by viewModels()
    private var imageAdapter : ImageAdapter? = null
    private var listImage: ArrayList<Image> = ArrayList()

    private var catId : String? = null
    private var typeToGetImage: Array<String>? = null
    private var sortBy: String? = null
    private var presentImageType: String? = null

    private var position : Int? = null

    private var canLoadMore : Boolean = true
    private var offset : Int = 0;


    public fun setData(catId : String?, position : Int?, typeToGetImage: Array<String>?, sortBy: String?, presentImageType: String?){
        this.catId = catId
        this.position = position
        this.typeToGetImage = typeToGetImage
        this.sortBy = sortBy
        this.presentImageType = presentImageType
    }

    override fun getLayoutRes(): Int {
        return R.layout.fragment_category_tab_detail
    }

    override fun initView() {
        binding?.swipeToRefresh?.setOnRefreshListener {
            reload()
            WeatherApplication.trackingEvent("Refresh_Category_detail")
        }
        imageAdapter = ImageAdapter(mActivity, listImage)
        imageAdapter?.setDataPresentImageType(Constant.PresentImageType.CATEGORY, catId, sortBy, typeToGetImage)
        binding?.rclContent?.adapter = imageAdapter
    }
    override fun initData() {
        getData()
        binding?.rclContent?.addOnScrollListener(object : RecyclerView.OnScrollListener(){
            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                super.onScrollStateChanged(recyclerView, newState)
                if (newState == RecyclerView.SCROLL_STATE_IDLE && !recyclerView.canScrollVertically(1)) {
                    getData()
                }
            }
        })
    }

    private fun getData(){
        if (canLoadMore){
            try {
                binding?.loadMoreProgressBar?.visibility = View.VISIBLE
            } catch (e: Exception) {
            }
            canLoadMore = false
            mainViewModel?.getImagesByCatId(
                catId,
                sortBy,
                typeToGetImage,
                null,
                "30",
                offset)
            try {
                WeatherApplication.trackingEvent("Load_more_data_Category_detail", "Offset", offset.toString())
            } catch (e: Exception) {
            }
        }
    }


    override fun setListener() {}
    override fun setObserver() {
        mainViewModel?.dataResponseLiveData?.observe(this, Observer {

            binding?.progressBar?.toGone()

            try {
                binding?.loadMoreProgressBar?.visibility = View.GONE
            } catch (e: Exception) {
            }

            binding?.swipeToRefresh?.isRefreshing = false
            if(it.offset == 0) {
                listImage.clear()
            }
            listImage.addAll(it.items)
            imageAdapter?.notifyDataSetChanged()
            canLoadMore = true
            offset += it.items.size



//            if(position == 0){
//                EventBus.getDefault().post(OnHaveBackdrop(listImage[0]?.variations?.adapted?.url))
//            }
        })

        mainViewModel.requestFail.observe(this) {
            canLoadMore = true
            binding?.progressBar?.toGone()
            binding?.tvRefresh?.toGone()

            try {
                binding?.loadMoreProgressBar?.visibility = View.GONE
            } catch (e: Exception) {
            }
            binding?.swipeToRefresh?.isRefreshing = false
        }
    }

    override fun getFrame(): Int {
        return R.id.mainFrame
    }

    private fun reload(){
        binding?.progressBar?.toVisible()
        offset = 0
        listImage.clear()
        imageAdapter?.notifyDataSetChanged()
        getData()
    }


}