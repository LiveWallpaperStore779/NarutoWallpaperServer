package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.iinterface;


import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.main.model.image.VariationItem;

public interface OnClickVariant {
    void onClickVariant(VariationItem variationItem);
}
