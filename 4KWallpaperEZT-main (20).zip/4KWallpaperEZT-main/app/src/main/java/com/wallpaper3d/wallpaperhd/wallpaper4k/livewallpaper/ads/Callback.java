//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ads;

public interface Callback {
    void callback();
}
