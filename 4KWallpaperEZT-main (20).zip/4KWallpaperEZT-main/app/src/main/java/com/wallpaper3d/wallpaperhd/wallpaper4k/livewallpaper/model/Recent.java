package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.model;

import androidx.room.Entity;

import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.main.model.image.Image;

@Entity
public class Recent extends Image {

}
