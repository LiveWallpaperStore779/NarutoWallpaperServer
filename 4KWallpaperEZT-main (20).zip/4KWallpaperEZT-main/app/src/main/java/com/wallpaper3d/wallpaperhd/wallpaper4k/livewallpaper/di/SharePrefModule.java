package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.di;

import android.content.Context;

import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.util.PreferenceUtil;

import dagger.Module;
import dagger.Provides;
import dagger.hilt.InstallIn;
import dagger.hilt.android.qualifiers.ApplicationContext;
import dagger.hilt.components.SingletonComponent;


@Module
@InstallIn(SingletonComponent.class)
public class SharePrefModule {
    @Provides
    public static PreferenceUtil providePreferenceUtil(@ApplicationContext Context context) {
        return new PreferenceUtil(context);
    }
}
