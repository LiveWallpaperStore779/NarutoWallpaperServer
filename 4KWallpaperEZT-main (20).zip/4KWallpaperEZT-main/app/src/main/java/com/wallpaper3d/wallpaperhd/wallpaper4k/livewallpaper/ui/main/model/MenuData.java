package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.main.model;

import java.util.ArrayList;

public class MenuData {

    private ArrayList<Menu> menu;

    public ArrayList<Menu> getMenu() {
        return menu;
    }

    public void setMenu(ArrayList<Menu> menu) {
        this.menu = menu;
    }
}
