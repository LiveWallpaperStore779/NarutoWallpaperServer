package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.splash.view

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import androidx.activity.viewModels
import androidx.fragment.app.viewModels
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.Constant
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.R
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.WeatherApplication
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ads.Callback
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ads.InterAds
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ads.OpenAds
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.base.BaseActivityNew
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.base.BaseFragment
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.databinding.ActivitySplashBinding
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.main.model.image.Image
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.main.view.MainActivity
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.main.viewmodel.WeatherViewModel
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.slideimage.view.DetailImageActivity
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.splash.SplashViewModel
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.util.PreferenceUtil
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class SplashActivity : BaseActivityNew<ActivitySplashBinding>() {

    private val weatherViewModel: SplashViewModel by viewModels()


    private var image : Image? = null



    private var isRunning = false
    private var isFetchFireBaseDone = false
    val new_ui = "new_ui"
    private var isLoadAdsDone = false
    private val isActivityStarted = false
    private val passDraw: String? = null
    @Inject
    lateinit var preferenceUtil: PreferenceUtil

    override fun getLayoutRes(): Int {
        return R.layout.activity_splash
    }

    override fun getFrame(): Int {
        return R.id.mainFrame
    }

    override fun getDataFromIntent() {
        image = intent.getSerializableExtra(Constant.IntentKey.DATA) as Image?
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        intent?.let {
            image = intent.getSerializableExtra(Constant.IntentKey.DATA) as Image?
        }

    }

    override fun afterSetContentView() {
        super.afterSetContentView()
        setFullScreen()
    }

    override fun doAfterOnCreate() {
//        Handler().postDelayed(Runnable {
////            WeatherApplication.get().showAdIfAvailable(this@SplashActivity, WeatherApplication.OnShowAdCompleteListener {
//                MainActivity.startScreen(this@SplashActivity)
//                finish()
////            })
//        }, 1000)

        pingAll()
        initAds()
    }

    override fun setListener() {
    }

    private fun setFullScreen() {
        super.afterSetContentView()
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
        window.statusBarColor = Color.TRANSPARENT
    }

    override fun initFragment(): BaseFragment<*>? {
        return null
    }

    private fun initAds() {
        if (isNetworkAvailable(this)) {
            initRemoteConfig()
            InterAds.initInterAds(this, null)
            isRunning = true
            val handler = Handler()
            val runnable = Runnable {
                isLoadAdsDone = true
                isFetchFireBaseDone = true
                yasuo()
            }
            handler.postDelayed(runnable, 5000)
            OpenAds.initOpenAds(this@SplashActivity) {
                isLoadAdsDone = true
                handler.removeCallbacks(runnable)
                if (!isDestroyed) {
                    yasuo()
                }
            }
        } else {
            Handler(Looper.getMainLooper()).postDelayed({ this@SplashActivity.intent("1") }, 400)
        }
    }

    private fun initRemoteConfig() {
        val mFirebaseRemoteConfig = FirebaseRemoteConfig.getInstance()
        val configSettings = FirebaseRemoteConfigSettings.Builder()
            .setMinimumFetchIntervalInSeconds(3600)
            .build()
        mFirebaseRemoteConfig.fetchAndActivate()
            .addOnCompleteListener(this) {
                isFetchFireBaseDone = true
                yasuo()
//                fetchConfig()
            }
    }

    private fun yasuo() {
        if (isFetchFireBaseDone && isLoadAdsDone && !isActivityStarted) {
            if (isRunning) {
                riven()
            } else {
                Handler(Looper.getMainLooper()).postDelayed({ this@SplashActivity.intent("2") }, 400)
            }
        }
    }

    private fun riven() {
        if (OpenAds.isCanShowOpenAds()) {
            OpenAds.showOpenAds(this, Callback {
                Handler(Looper.getMainLooper()).postDelayed(
                    {
                        intent("3")
                    },
                    400
                )
            })
        } else {
            intent("4")
        }
    }

    private fun intent(debug : String){
        Log.e("trackingggg", debug)
        MainActivity.startScreen(this@SplashActivity, image)
        finish()
    }

    fun isNetworkAvailable(context: Context): Boolean {
        val manager = context.getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        var networkInfo: NetworkInfo? = null
        if (manager != null) {
            networkInfo = manager.activeNetworkInfo
        }
        var isAvailable = false
        if (networkInfo != null && networkInfo.isConnected) {
            // Network is present and connected
            isAvailable = true
        }
        return isAvailable
    }

    override fun onResume() {
        super.onResume()
        isRunning = true
    }

    override fun onPause() {
        super.onPause()
        isRunning = false
    }

    private fun pingAll(){

        weatherViewModel.getImagesByCatId(null, Constant.SortBy.RATING, null, null,"60", 0) // home


        val type: Array<String> = arrayOf("private")
        weatherViewModel.getImagesByCatId(null, Constant.SortBy.RATING, type, null,"60", 0) // special tab


        val uploader: Array<String> = arrayOf("wlc_ai_art")
        weatherViewModel.getImagesByCatId(null, Constant.SortBy.RATING, type, uploader,"60", 0)


        weatherViewModel.getImagesByCatId("192", Constant.SortBy.DOWNLOAD, type, null,"60", 0)

        weatherViewModel.getLiveWallpaper( Constant.SortBy.DOWNLOAD, "android_video", "30", 0)

        weatherViewModel.getAllCat()
    }
}