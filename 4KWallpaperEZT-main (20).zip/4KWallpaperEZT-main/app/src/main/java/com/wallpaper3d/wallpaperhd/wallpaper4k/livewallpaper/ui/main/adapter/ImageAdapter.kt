package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.main.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.gson.Gson
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.R
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.WeatherApplication
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.databinding.ItemImageBinding
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.databinding.LayoutPromotionBinding
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.main.PromotionData
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.main.adapter.viewholder.AdsViewHolder
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.main.model.image.Image
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.slideimage.view.DetailImageActivity
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.util.Util
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.util.toGone
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.util.toVisible

class ImageAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder> {
    public val TYPE_ITEM = 0
    public val TYPE_PROMOTION = 1
    public val TYPE_ADS = 2
    private var context: Context? = null
    private var images: List<Image>? = null
    private var canLoadMoreWhenClickToDetail: Boolean = true

    private var presentImageType: String? = null
    private var catId: String? = null
    private var sortBy: String? = null
    private var typeToGetImage: Array<String>? = null
    private var keyword: String? = null

    private var isShowPromotion = false


    constructor()
    constructor(context: Context?, datas: List<Image>?) : super() {
        this.context = context
        this.images = datas
    }

    constructor(
        context: Context?,
        datas: List<Image>?,
        canLoadMoreWhenClickToDetail: Boolean,
        isShowPromotion: Boolean
    ) : super() {
        this.context = context
        this.images = datas
        this.canLoadMoreWhenClickToDetail = canLoadMoreWhenClickToDetail
        this.isShowPromotion = isShowPromotion

    }

    public fun setDataPresentImageType(
        presentImageType: String?,
        catId: String?,
        sortBy: String?,
        typeToGetImage: Array<String>?
    ) {
        this.presentImageType = presentImageType
        this.catId = catId
        this.sortBy = sortBy
        this.typeToGetImage = typeToGetImage
    }

    public fun setDataPresentImageType(keyword: String?) {
        this.keyword = keyword
    }


    override fun getItemViewType(position: Int): Int {
//        if (isShowPromotion) {
//            if (position == 0) {
//                return TYPE_PROMOTION
//            } else {
//                if(position % 10 == 0){
//                    return TYPE_ADS
//                }else {
//                    return TYPE_ITEM
//                }
//            }
//        } else {
//            if(position % 10 == 0){
//                return TYPE_ADS
//            }else {
//                return TYPE_ITEM
//            }
//        }

        if(images!![position].itemType == TYPE_PROMOTION){
            return TYPE_PROMOTION
        }else if(images!![position].itemType == TYPE_ADS){
            return TYPE_ADS
        }else{
            return TYPE_ITEM
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)

        var v: View? = null
        return if (viewType == TYPE_ITEM) {
            val binding: ItemImageBinding = ItemImageBinding.inflate(inflater, parent, false)
            ViewHolder(binding)
        } else if (viewType == TYPE_ADS) {
            val v: View =
                LayoutInflater.from(parent.context).inflate(R.layout.layout_ads, parent, false)
            AdsViewHolder(v, context)
        }else{
            val binding: LayoutPromotionBinding = LayoutPromotionBinding.inflate(inflater, parent, false)
            PromotionViewHolder(binding)
        }

    }

    override fun getItemCount(): Int {
        try {
            return images!!.size;
        } catch (e: Exception) {
            return 0
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        try {
            if (getItemViewType(position) == TYPE_ITEM) {
                (holder as ViewHolder).bindItem(position)
            } else if (getItemViewType(position) == TYPE_PROMOTION) {
                (holder as PromotionViewHolder).bindItem(position)
            }else if(getItemViewType(position) == TYPE_ADS){
                (holder as AdsViewHolder).bind(R.layout.ad_unified, images, position)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    inner class ViewHolder (var binding: ItemImageBinding) : RecyclerView.ViewHolder(binding.root) {
        private var position: Int? = 0;

        init {

        }

        fun bindItem(position: Int) {
            this.position = position

//            if(images!![position].content_type.equals("private")){
//                binding.imgShowAds.toVisible()
//            }else{
//                binding.imgShowAds.toGone()
//            }
            val link = images!![position].variations.preview_small.url
            Glide.with(context!!).load(link).into(binding.imgAvatar)
            binding.root.setOnClickListener {
                WeatherApplication.trackingEvent("Click_Item_Image")
                DetailImageActivity.startScreen(
                    context!!,
                    catId,
                    images as ArrayList<Image>,
                    position,
                    canLoadMoreWhenClickToDetail,
                    sortBy,
                    typeToGetImage,
                    presentImageType,
                    keyword,
                    false,
                    null,
                    true
                )
            }
        }

    }

    inner class PromotionViewHolder(var binding: LayoutPromotionBinding) : RecyclerView.ViewHolder(binding.root) {
        private var position: Int? = 0;
        private var slidePromotionAdapter: SlidePromotionAdapter? = null



        fun bindItem(position: Int) {
            this.position = position
            var promotion = Gson().fromJson(
                Util.loadJSONFromAsset(context, "promotion"),
                PromotionData::class.java
            )
            slidePromotionAdapter = SlidePromotionAdapter(context, promotion.menu)
            binding.vpContent.adapter = slidePromotionAdapter
//            binding.indicator.attachToViewPager(binding.vpContent)
        }

    }

}

