package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.iinterface;

public interface FoodCloseAds {
    public void onCloseAds();
}
