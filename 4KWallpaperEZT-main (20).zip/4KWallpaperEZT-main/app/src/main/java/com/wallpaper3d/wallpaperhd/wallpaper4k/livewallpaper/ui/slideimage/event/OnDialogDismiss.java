package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.slideimage.event;

public class OnDialogDismiss {
}
