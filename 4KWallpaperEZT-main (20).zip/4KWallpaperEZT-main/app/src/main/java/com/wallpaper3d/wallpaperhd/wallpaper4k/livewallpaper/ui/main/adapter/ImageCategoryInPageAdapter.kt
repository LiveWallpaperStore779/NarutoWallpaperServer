package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.main.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.WeatherApplication
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.databinding.ItemImageCategoryInPageBinding
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.iinterface.DataChange
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.categorydetail.view.CategoryDetailActivity
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.main.model.category.Category
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.main.model.image.Image
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.slideimage.view.DetailImageActivity
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.util.toGone
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.util.toVisible

class ImageCategoryInPageAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private val TYPE_ITEM = 0
    private val TYPE_SEE_MORE = 1
    private var context: Context? = null
    private var images: List<Image>? = null
    private var dataChange: DataChange? = null
    private var category: Category? = null;

    private var presentImageType: String? = null
    private var catId: String? = null
    private var sortBy: String? = null
    private var typeToGetImage: Array<String>? = null

    constructor()
    constructor(context: Context?, datas: List<Image>?) : super() {
        this.context = context
        this.images = datas
    }

    constructor(
        context: Context?,
        datas: List<Image>?,
        category: Category?,
        dataChange: DataChange?
    ) : super() {
        this.context = context
        this.images = datas
        this.dataChange = dataChange
        this.category = category
    }

    public fun setDataPresentImageType(
        presentImageType: String?,
        catId: String?,
        sortBy: String?,
        typeToGetImage: Array<String>?
    ) {
        this.presentImageType = presentImageType
        this.catId = catId
        this.sortBy = sortBy
        this.typeToGetImage = typeToGetImage
    }


    override fun getItemViewType(position: Int): Int {
        if (position == images!!.size) {
            return TYPE_SEE_MORE
        } else {
            return TYPE_ITEM
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding: ItemImageCategoryInPageBinding = ItemImageCategoryInPageBinding.inflate(inflater, parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        try {
            return images!!.size
        } catch (e: Exception) {

            return 0
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        try {
            if (getItemViewType(position) == TYPE_ITEM) {
                (holder as ViewHolder).bindItem(position)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    inner class ViewHolder (var binding: ItemImageCategoryInPageBinding) : RecyclerView.ViewHolder(binding.root) {
        private var position: Int? = 0;


        init {

        }

        fun bindItem(position: Int) {
            this.position = position
            val link = images!![position].variations.preview_small.url
            Glide.with(context!!).load(link).into(binding.imgAvatar)
            itemView.setOnClickListener {
                WeatherApplication.trackingEvent("Click_Image_In_category_inPage")
                DetailImageActivity.startScreen(context!!, category?.id, images as ArrayList<Image>, position, true, sortBy, typeToGetImage, presentImageType, null, false, null, true)
            }
            if(position == images!!.size - 1){
                binding.layoutCover.toVisible()

                itemView.setOnClickListener {
                    WeatherApplication.trackingEvent("Click_See_more")
                    CategoryDetailActivity.startScreen(context!!, category)
                }
            }else{
                binding.layoutCover.toGone()
            }

        }

    }


}

