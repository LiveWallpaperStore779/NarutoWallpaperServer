package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.iinterface;

public interface OnClick {
    void onClickToMainScreen();
    void onClickToLockScreen();
    void onClickToBoth();
}
