package com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ui.charging.view

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.util.Log
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.R
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.ads.InterAds
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.base.BaseActivityNew
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.base.BaseFragment
import com.wallpaper3d.wallpaperhd.wallpaper4k.livewallpaper.databinding.ActivityChargingAnimationDetailBinding

class ChargingDetailActivity : BaseActivityNew<ActivityChargingAnimationDetailBinding?>() {
    private var json: String? = null
    override fun getLayoutRes(): Int {
        return R.layout.activity_charging_animation_detail
    }

    override fun getFrame(): Int {
        return R.id.mainFrame
    }

    override fun getDataFromIntent() {
        json = intent.getStringExtra("json")
    }

    override fun doAfterOnCreate() {
        initBanner(binding?.adViewContainer)
    }
    override fun setListener() {}
    override fun initFragment(): BaseFragment<*> {
        return ChargingAnimationPreviewFragment.newInstance(json)
    }

    public companion object {
        public fun startScreen(context: Context, json: String?) {
            InterAds.showAdsBreak(context as Activity) {
                try {
                    var intent = Intent(context, ChargingDetailActivity::class.java)
                    intent.putExtra("json", json)
                    context.startActivity(intent)
                } catch (e: Exception) {
                    Log.e("", "")
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        initBanner(binding?.adViewContainer)
    }
}