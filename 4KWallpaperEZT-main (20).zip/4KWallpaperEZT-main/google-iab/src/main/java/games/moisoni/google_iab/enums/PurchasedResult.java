package games.moisoni.google_iab.enums;

public enum PurchasedResult {
    CLIENT_NOT_READY,
    PURCHASED_PRODUCTS_NOT_FETCHED_YET,
    YES,
    NO
}