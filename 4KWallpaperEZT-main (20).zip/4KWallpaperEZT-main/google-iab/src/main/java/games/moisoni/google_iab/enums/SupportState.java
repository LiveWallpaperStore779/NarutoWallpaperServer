package games.moisoni.google_iab.enums;

public enum SupportState {
    SUPPORTED,
    NOT_SUPPORTED,
    DISCONNECTED
}
