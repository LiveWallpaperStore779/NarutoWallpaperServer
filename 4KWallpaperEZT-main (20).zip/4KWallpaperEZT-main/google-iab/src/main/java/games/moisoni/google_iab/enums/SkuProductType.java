package games.moisoni.google_iab.enums;

public enum SkuProductType {
    CONSUMABLE,
    NON_CONSUMABLE,
    SUBSCRIPTION
}
